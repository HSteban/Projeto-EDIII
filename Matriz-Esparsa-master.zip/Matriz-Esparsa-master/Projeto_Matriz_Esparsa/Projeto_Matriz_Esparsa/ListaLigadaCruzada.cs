﻿//Lucca Pavanaatti Duarte - 18184
//Vítor de Melo Calhau - 18044
// Hercules Magaldi - 18195
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Matriz_Esparsa
{
    class ListaLigadaCruzada
    {
        Celula noPrincipal, atualLinha, atualColuna, anteriorColuna, anteriorLinha;
        int linha, coluna; 
        public int Linha
        {
            get => linha;
        }
        public int Coluna
        {
            get => coluna;
        }

        public ListaLigadaCruzada(int linha, int coluna)
        {
            noPrincipal = new Celula(-1, -1, 0);
            this.linha = linha;
            this.coluna = coluna;

            Celula atual = noPrincipal;

            for(int i=0;i<linha;i++)
            {
                Celula linhaCelula = new Celula(i, -1, 0);
                atual.Abaixo = linhaCelula;
                atual = linhaCelula;
                atual.Direita = atual;
            }
            atual.Abaixo = noPrincipal;

            atual = noPrincipal;

            for (int i = 0; i < coluna; i++)
            {
                Celula colunaCelula = new Celula(-1, i, 0);
                atual.Direita = colunaCelula;
                atual = colunaCelula;
                atual.Abaixo = atual;
            }

            atual.Direita = noPrincipal;
        }


        public void ExibirNoGridView(DataGridView dgv)
        {
            /*dgv.Rows.Clear();
            dgv.Columns.Clear();

            dgv.RowCount = linha;
            dgv.ColumnCount = coluna;

            Celula atualLinha = noPrincipal.Abaixo;
            Celula atualColuna = noPrincipal;

            while (atualColuna.Direita != noPrincipal)
            {
                while (atualLinha != atualColuna)
                {
                    dgv[atualLinha.Coluna+1, atualLinha.Linha].Value = atualLinha.Valor;
                    atualLinha = atualLinha.Abaixo;
                }
                atualLinha = atualColuna.Abaixo;
                atualColuna = atualColuna.Direita;
            }*/
            dgv.ColumnCount = coluna;
            dgv.RowCount = linha;

            Celula atualLinha = noPrincipal.Abaixo;
            Celula atualColuna = noPrincipal.Direita;

            for (int i = 0; i < linha; i++)
            {
                for (int j = 0; j < coluna; j++)
                {
                     dgv[j, i].Value = atualColuna.Valor;
                    dgv.Rows[i].HeaderCell.Value = i.ToString();
                    dgv.Columns[j].HeaderCell.Value = j.ToString();
                }
            }
            dgv.AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders);
            dgv.AutoResizeColumns();
        }

        public bool Existe(int linhas, int colunas)
        {
            atualLinha = noPrincipal;
            atualColuna = noPrincipal;
            anteriorLinha = null;
            anteriorColuna = null;


            while (atualLinha.Linha != linhas && atualLinha.Abaixo != atualLinha)
            {
                anteriorLinha = atualLinha;
                atualLinha = atualLinha.Abaixo;
            }

            while (atualLinha.Coluna != colunas && atualLinha.Direita != atualLinha)
            {
                anteriorLinha = atualLinha;
                atualLinha = atualLinha.Direita;
            }

            while (atualColuna.Coluna != colunas && atualColuna.Direita != atualColuna)
            {
               anteriorColuna = atualColuna;
               atualColuna = atualColuna.Direita;
            }

           while (atualColuna.Linha != linhas && atualColuna.Abaixo != atualColuna)
           {
               anteriorColuna = atualColuna;
               atualColuna = atualColuna.Abaixo;
           }

           if (atualLinha.Linha != linhas || atualColuna.Coluna != colunas)
               return false;

           return true;
        }

        public void Inserir(int l,int c,double valor)
        {
            if (l <= 0 || c <= 0)
                throw new Exception("Celula inválida");

            if (valor == 0)
                return;

            if (Existe(l, c))
                atualColuna.Valor = valor;

            else
            {
                Celula celulaInserida = new Celula(l, c, valor);

                anteriorColuna.Abaixo = celulaInserida;
                celulaInserida.Abaixo = atualColuna;

                anteriorLinha.Direita = celulaInserida;
                celulaInserida.Direita = atualLinha;
            }
            
        }
        public double ValorDe(int linha, int coluna)
        {
            if (linha < 0 || coluna < 0 ||
                linha >= Linha || coluna >= Coluna)
                throw new ArgumentOutOfRangeException("Linha ou coluna estão foras do intervalo de pesquisa.");

            Celula linhaCabeca = noPrincipal;

            for (int i = 0; i <= linha; i++)
                linhaCabeca = linhaCabeca.Abaixo;

            Celula percursoColuna = linhaCabeca.Direita;

            while (percursoColuna.Coluna < coluna && percursoColuna.Direita != linhaCabeca)
                percursoColuna = percursoColuna.Direita;

            if (percursoColuna.Coluna != coluna)
                return 0;

            return percursoColuna.Valor;
        }

    }
}
