﻿//Lucca Pavanaatti Duarte - 18184
//Vítor de Melo Calhau - 18044
// Hercules Magaldi - 18195

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Matriz_Esparsa
{
    
    public partial class Form1 : Form
    {
        ListaLigadaCruzada matrizEsparsa;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGerarMatriz_Click(object sender, EventArgs e)
        {
            int linha = (int) numLinhas.Value;
            int coluna = (int)numColunas.Value;

            matrizEsparsa = new ListaLigadaCruzada(linha, coluna);
            matrizEsparsa.ExibirNoGridView(dgvMatriz);
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            int linha = (int)numLinhas.Value;
            int coluna = (int)numColunas.Value;
            double elemento = Convert.ToDouble(txtDadoInserido.Text);

            matrizEsparsa.Inserir(linha-1, coluna-1, elemento);
            matrizEsparsa.ExibirNoGridView(dgvMatriz);
            
        }

        private void btnGerarMatrizA_Click(object sender, EventArgs e)
        {
            int linha = (int)numLinhasA.Value;
            int coluna = (int)numColunasA.Value;

            matrizEsparsa = new ListaLigadaCruzada(linha, coluna);
            matrizEsparsa.ExibirNoGridView(dgvMatrizA);
        }

        private void btnGerarMatrizB_Click(object sender, EventArgs e)
        {
            int linha = (int)numLinhasB.Value;
            int coluna = (int)numColunasB.Value;

            matrizEsparsa = new ListaLigadaCruzada(linha, coluna);
            matrizEsparsa.ExibirNoGridView(dgvMatrizB);
        }
    }
}
