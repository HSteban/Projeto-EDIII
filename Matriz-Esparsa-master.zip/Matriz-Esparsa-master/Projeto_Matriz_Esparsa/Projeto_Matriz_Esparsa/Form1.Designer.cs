﻿namespace Projeto_Matriz_Esparsa
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtConstante = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.numColunaSomar = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.numLinhasPesquisa = new System.Windows.Forms.NumericUpDown();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.numColunasPesquisa = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numLinhasExcluir = new System.Windows.Forms.NumericUpDown();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.numColunasExcluir = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtDadoInserido = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.numLinhasInserir = new System.Windows.Forms.NumericUpDown();
            this.btnInserir = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.numColunasInserir = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvMatriz = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numLinhas = new System.Windows.Forms.NumericUpDown();
            this.btnGerarMatriz = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.numColunas = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvMatrizB = new System.Windows.Forms.DataGridView();
            this.dgvMatrizA = new System.Windows.Forms.DataGridView();
            this.btnLerArquivo = new System.Windows.Forms.Button();
            this.btbDesalocarMatriz = new System.Windows.Forms.Button();
            this.btnMultiplicarMatriz = new System.Windows.Forms.Button();
            this.btnSomarMatriz = new System.Windows.Forms.Button();
            this.btnGerarMatrizA = new System.Windows.Forms.Button();
            this.btnGerarMatrizB = new System.Windows.Forms.Button();
            this.numLinhasA = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.numColunasA = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.numLinhasB = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.numColunasB = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.dgvOperacoes = new System.Windows.Forms.DataGridView();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numColunaSomar)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasPesquisa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasPesquisa)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasExcluir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasExcluir)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasInserir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasInserir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrizB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrizA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOperacoes)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtConstante);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.btnSomar);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.numColunaSomar);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(804, 26);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(179, 131);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Somar dado na coluna";
            // 
            // txtConstante
            // 
            this.txtConstante.Location = new System.Drawing.Point(88, 67);
            this.txtConstante.Name = "txtConstante";
            this.txtConstante.Size = new System.Drawing.Size(85, 20);
            this.txtConstante.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 67);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 20);
            this.label12.TabIndex = 7;
            this.label12.Text = "Número:";
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(24, 99);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(102, 23);
            this.btnSomar.TabIndex = 4;
            this.btnSomar.Text = "Somar na coluna";
            this.btnSomar.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "Coluna:";
            // 
            // numColunaSomar
            // 
            this.numColunaSomar.Location = new System.Drawing.Point(88, 38);
            this.numColunaSomar.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunaSomar.Name = "numColunaSomar";
            this.numColunaSomar.Size = new System.Drawing.Size(58, 20);
            this.numColunaSomar.TabIndex = 3;
            this.numColunaSomar.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.numLinhasPesquisa);
            this.groupBox4.Controls.Add(this.btnPesquisar);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.numColunasPesquisa);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(608, 22);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(190, 141);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Pesquisar Dado";
            // 
            // numLinhasPesquisa
            // 
            this.numLinhasPesquisa.Location = new System.Drawing.Point(80, 51);
            this.numLinhasPesquisa.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhasPesquisa.Name = "numLinhasPesquisa";
            this.numLinhasPesquisa.Size = new System.Drawing.Size(58, 20);
            this.numLinhasPesquisa.TabIndex = 1;
            this.numLinhasPesquisa.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(49, 106);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 4;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Coluna:";
            // 
            // numColunasPesquisa
            // 
            this.numColunasPesquisa.Location = new System.Drawing.Point(80, 80);
            this.numColunasPesquisa.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunasPesquisa.Name = "numColunasPesquisa";
            this.numColunasPesquisa.Size = new System.Drawing.Size(58, 20);
            this.numColunasPesquisa.TabIndex = 3;
            this.numColunasPesquisa.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Linha:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numLinhasExcluir);
            this.groupBox3.Controls.Add(this.btnExcluir);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.numColunasExcluir);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(423, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(179, 141);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Excluir dado";
            // 
            // numLinhasExcluir
            // 
            this.numLinhasExcluir.Location = new System.Drawing.Point(91, 48);
            this.numLinhasExcluir.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhasExcluir.Name = "numLinhasExcluir";
            this.numLinhasExcluir.Size = new System.Drawing.Size(58, 20);
            this.numLinhasExcluir.TabIndex = 1;
            this.numLinhasExcluir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnExcluir
            // 
            this.btnExcluir.Location = new System.Drawing.Point(47, 106);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(75, 23);
            this.btnExcluir.TabIndex = 4;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Coluna:";
            // 
            // numColunasExcluir
            // 
            this.numColunasExcluir.Location = new System.Drawing.Point(91, 77);
            this.numColunasExcluir.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunasExcluir.Name = "numColunasExcluir";
            this.numColunasExcluir.Size = new System.Drawing.Size(58, 20);
            this.numColunasExcluir.TabIndex = 3;
            this.numColunasExcluir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Linha:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtDadoInserido);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.numLinhasInserir);
            this.groupBox2.Controls.Add(this.btnInserir);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.numColunasInserir);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(227, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(190, 144);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inserir Dado";
            // 
            // txtDadoInserido
            // 
            this.txtDadoInserido.Location = new System.Drawing.Point(75, 15);
            this.txtDadoInserido.Name = "txtDadoInserido";
            this.txtDadoInserido.Size = new System.Drawing.Size(100, 20);
            this.txtDadoInserido.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Dado:";
            // 
            // numLinhasInserir
            // 
            this.numLinhasInserir.Location = new System.Drawing.Point(75, 51);
            this.numLinhasInserir.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhasInserir.Name = "numLinhasInserir";
            this.numLinhasInserir.Size = new System.Drawing.Size(58, 20);
            this.numLinhasInserir.TabIndex = 1;
            this.numLinhasInserir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnInserir
            // 
            this.btnInserir.Location = new System.Drawing.Point(48, 106);
            this.btnInserir.Name = "btnInserir";
            this.btnInserir.Size = new System.Drawing.Size(75, 23);
            this.btnInserir.TabIndex = 4;
            this.btnInserir.Text = "Inserir";
            this.btnInserir.UseVisualStyleBackColor = true;
            this.btnInserir.Click += new System.EventHandler(this.btnInserir_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Coluna:";
            // 
            // numColunasInserir
            // 
            this.numColunasInserir.Location = new System.Drawing.Point(75, 80);
            this.numColunasInserir.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunasInserir.Name = "numColunasInserir";
            this.numColunasInserir.Size = new System.Drawing.Size(58, 20);
            this.numColunasInserir.TabIndex = 3;
            this.numColunasInserir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Linha:";
            // 
            // dgvMatriz
            // 
            this.dgvMatriz.AllowUserToAddRows = false;
            this.dgvMatriz.AllowUserToDeleteRows = false;
            this.dgvMatriz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz.Location = new System.Drawing.Point(42, 165);
            this.dgvMatriz.Name = "dgvMatriz";
            this.dgvMatriz.ReadOnly = true;
            this.dgvMatriz.Size = new System.Drawing.Size(941, 179);
            this.dgvMatriz.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numLinhas);
            this.groupBox1.Controls.Add(this.btnGerarMatriz);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.numColunas);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(42, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 144);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gerar Matriz Esparsa";
            // 
            // numLinhas
            // 
            this.numLinhas.Location = new System.Drawing.Point(93, 54);
            this.numLinhas.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhas.Name = "numLinhas";
            this.numLinhas.Size = new System.Drawing.Size(58, 20);
            this.numLinhas.TabIndex = 1;
            this.numLinhas.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnGerarMatriz
            // 
            this.btnGerarMatriz.Location = new System.Drawing.Point(43, 109);
            this.btnGerarMatriz.Name = "btnGerarMatriz";
            this.btnGerarMatriz.Size = new System.Drawing.Size(75, 23);
            this.btnGerarMatriz.TabIndex = 4;
            this.btnGerarMatriz.Text = "Gerar Matriz";
            this.btnGerarMatriz.UseVisualStyleBackColor = true;
            this.btnGerarMatriz.Click += new System.EventHandler(this.btnGerarMatriz_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Colunas:";
            // 
            // numColunas
            // 
            this.numColunas.Location = new System.Drawing.Point(93, 83);
            this.numColunas.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunas.Name = "numColunas";
            this.numColunas.Size = new System.Drawing.Size(58, 20);
            this.numColunas.TabIndex = 3;
            this.numColunas.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Linhas:";
            // 
            // dgvMatrizB
            // 
            this.dgvMatrizB.AllowUserToAddRows = false;
            this.dgvMatrizB.AllowUserToDeleteRows = false;
            this.dgvMatrizB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatrizB.Location = new System.Drawing.Point(285, 458);
            this.dgvMatrizB.Name = "dgvMatrizB";
            this.dgvMatrizB.ReadOnly = true;
            this.dgvMatrizB.Size = new System.Drawing.Size(240, 295);
            this.dgvMatrizB.TabIndex = 17;
            // 
            // dgvMatrizA
            // 
            this.dgvMatrizA.AllowUserToAddRows = false;
            this.dgvMatrizA.AllowUserToDeleteRows = false;
            this.dgvMatrizA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatrizA.Location = new System.Drawing.Point(33, 458);
            this.dgvMatrizA.Name = "dgvMatrizA";
            this.dgvMatrizA.ReadOnly = true;
            this.dgvMatrizA.Size = new System.Drawing.Size(227, 295);
            this.dgvMatrizA.TabIndex = 18;
            // 
            // btnLerArquivo
            // 
            this.btnLerArquivo.Location = new System.Drawing.Point(760, 360);
            this.btnLerArquivo.Name = "btnLerArquivo";
            this.btnLerArquivo.Size = new System.Drawing.Size(144, 34);
            this.btnLerArquivo.TabIndex = 18;
            this.btnLerArquivo.Text = "Ler de Arquivo";
            this.btnLerArquivo.UseVisualStyleBackColor = true;
            // 
            // btbDesalocarMatriz
            // 
            this.btbDesalocarMatriz.Location = new System.Drawing.Point(602, 360);
            this.btbDesalocarMatriz.Name = "btbDesalocarMatriz";
            this.btbDesalocarMatriz.Size = new System.Drawing.Size(144, 33);
            this.btbDesalocarMatriz.TabIndex = 20;
            this.btbDesalocarMatriz.Text = "Desalocar matriz";
            this.btbDesalocarMatriz.UseVisualStyleBackColor = true;
            // 
            // btnMultiplicarMatriz
            // 
            this.btnMultiplicarMatriz.Location = new System.Drawing.Point(760, 408);
            this.btnMultiplicarMatriz.Name = "btnMultiplicarMatriz";
            this.btnMultiplicarMatriz.Size = new System.Drawing.Size(144, 33);
            this.btnMultiplicarMatriz.TabIndex = 21;
            this.btnMultiplicarMatriz.Text = "Multiplicar Matriz";
            this.btnMultiplicarMatriz.UseVisualStyleBackColor = true;
            // 
            // btnSomarMatriz
            // 
            this.btnSomarMatriz.Location = new System.Drawing.Point(602, 408);
            this.btnSomarMatriz.Name = "btnSomarMatriz";
            this.btnSomarMatriz.Size = new System.Drawing.Size(144, 33);
            this.btnSomarMatriz.TabIndex = 22;
            this.btnSomarMatriz.Text = "Somar Matrizes";
            this.btnSomarMatriz.UseVisualStyleBackColor = true;
            // 
            // btnGerarMatrizA
            // 
            this.btnGerarMatrizA.Location = new System.Drawing.Point(73, 365);
            this.btnGerarMatrizA.Name = "btnGerarMatrizA";
            this.btnGerarMatrizA.Size = new System.Drawing.Size(131, 29);
            this.btnGerarMatrizA.TabIndex = 5;
            this.btnGerarMatrizA.Text = "Gerar Matriz A";
            this.btnGerarMatrizA.UseVisualStyleBackColor = true;
            this.btnGerarMatrizA.Click += new System.EventHandler(this.btnGerarMatrizA_Click);
            // 
            // btnGerarMatrizB
            // 
            this.btnGerarMatrizB.Location = new System.Drawing.Point(315, 365);
            this.btnGerarMatrizB.Name = "btnGerarMatrizB";
            this.btnGerarMatrizB.Size = new System.Drawing.Size(131, 29);
            this.btnGerarMatrizB.TabIndex = 23;
            this.btnGerarMatrizB.Text = "Gerar Matriz B";
            this.btnGerarMatrizB.UseVisualStyleBackColor = true;
            this.btnGerarMatrizB.Click += new System.EventHandler(this.btnGerarMatrizB_Click);
            // 
            // numLinhasA
            // 
            this.numLinhasA.Location = new System.Drawing.Point(146, 397);
            this.numLinhasA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhasA.Name = "numLinhasA";
            this.numLinhasA.Size = new System.Drawing.Size(58, 20);
            this.numLinhasA.TabIndex = 6;
            this.numLinhasA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(69, 423);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 20);
            this.label13.TabIndex = 7;
            this.label13.Text = "Colunas:";
            // 
            // numColunasA
            // 
            this.numColunasA.Location = new System.Drawing.Point(146, 426);
            this.numColunasA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunasA.Name = "numColunasA";
            this.numColunasA.Size = new System.Drawing.Size(58, 20);
            this.numColunasA.TabIndex = 8;
            this.numColunasA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(69, 397);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 5;
            this.label14.Text = "Linhas:";
            // 
            // numLinhasB
            // 
            this.numLinhasB.Location = new System.Drawing.Point(388, 397);
            this.numLinhasB.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLinhasB.Name = "numLinhasB";
            this.numLinhasB.Size = new System.Drawing.Size(58, 20);
            this.numLinhasB.TabIndex = 25;
            this.numLinhasB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(311, 423);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 20);
            this.label15.TabIndex = 26;
            this.label15.Text = "Colunas:";
            // 
            // numColunasB
            // 
            this.numColunasB.Location = new System.Drawing.Point(388, 426);
            this.numColunasB.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColunasB.Name = "numColunasB";
            this.numColunasB.Size = new System.Drawing.Size(58, 20);
            this.numColunasB.TabIndex = 27;
            this.numColunasB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(311, 397);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 20);
            this.label16.TabIndex = 24;
            this.label16.Text = "Linhas:";
            // 
            // dgvOperacoes
            // 
            this.dgvOperacoes.AllowUserToAddRows = false;
            this.dgvOperacoes.AllowUserToDeleteRows = false;
            this.dgvOperacoes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOperacoes.Location = new System.Drawing.Point(543, 458);
            this.dgvOperacoes.Name = "dgvOperacoes";
            this.dgvOperacoes.ReadOnly = true;
            this.dgvOperacoes.Size = new System.Drawing.Size(450, 295);
            this.dgvOperacoes.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 765);
            this.Controls.Add(this.dgvOperacoes);
            this.Controls.Add(this.numLinhasB);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.numColunasB);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.numLinhasA);
            this.Controls.Add(this.btnGerarMatrizB);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnGerarMatrizA);
            this.Controls.Add(this.numColunasA);
            this.Controls.Add(this.btnSomarMatriz);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btnMultiplicarMatriz);
            this.Controls.Add(this.btbDesalocarMatriz);
            this.Controls.Add(this.btnLerArquivo);
            this.Controls.Add(this.dgvMatrizA);
            this.Controls.Add(this.dgvMatrizB);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgvMatriz);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numColunaSomar)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasPesquisa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasPesquisa)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasExcluir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasExcluir)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasInserir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasInserir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrizB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrizA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinhasB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColunasB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOperacoes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtConstante;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numColunaSomar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown numLinhasPesquisa;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numColunasPesquisa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown numLinhasExcluir;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numColunasExcluir;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtDadoInserido;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numLinhasInserir;
        private System.Windows.Forms.Button btnInserir;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numColunasInserir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvMatriz;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numLinhas;
        private System.Windows.Forms.Button btnGerarMatriz;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numColunas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvMatrizB;
        private System.Windows.Forms.DataGridView dgvMatrizA;
        private System.Windows.Forms.Button btnLerArquivo;
        private System.Windows.Forms.Button btbDesalocarMatriz;
        private System.Windows.Forms.Button btnMultiplicarMatriz;
        private System.Windows.Forms.Button btnSomarMatriz;
        private System.Windows.Forms.Button btnGerarMatrizA;
        private System.Windows.Forms.Button btnGerarMatrizB;
        private System.Windows.Forms.NumericUpDown numLinhasA;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numColunasA;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown numLinhasB;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown numColunasB;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView dgvOperacoes;
    }
}

