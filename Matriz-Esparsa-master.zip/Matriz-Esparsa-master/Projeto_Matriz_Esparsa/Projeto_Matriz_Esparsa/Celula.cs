﻿//Lucca Pavanaatti Duarte - 18184
//Vítor de Melo Calhau - 18044
// Hercules Magaldi - 18195
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Matriz_Esparsa
{
    class Celula
    {
        private Celula abaixo, direita;
        private int linha, coluna;
        private double valor;

        public Celula(int linha, int coluna, double valor)
        {
            this.linha = linha;
            this.coluna = coluna;
            this.valor = valor;
        }

        public int Linha { get => linha; set => linha = value; }
        public int Coluna { get => coluna; set => coluna = value; }
        public double Valor { get => valor; set => valor = value; }
        public Celula Abaixo { get => abaixo; set => abaixo = value; }
        public Celula Direita { get => direita; set => direita = value; }
    }
}
